<p align="center">
<a href="https://www.npmjs.com/package/upimg">
<img src="https://user-images.githubusercontent.com/2666735/48976182-3dbbc080-f0bd-11e8-85f8-25533486dce1.png">
</a>
</p>

<p align="center">
<a href="https://i-meto.com"><img alt="Author" src="https://img.shields.io/badge/Author-METO-blue.svg?style=flat-square"/></a>
<a href="https://www.npmjs.com/package/upimg"><img alt="Version" src="https://img.shields.io/npm/v/upimg.svg?style=flat-square"/></a>
<img alt="License" src="https://img.shields.io/npm/l/upimg.svg?style=flat-square"/>
</p>


## Usage

### Installation

```bash
npm install upimg
```
or
```bash
yarn add upimg
```

### Require module

```javascript
const upimg = require('upimg')
```

### Support servers

|server|endpoint|auth|url|status|
|:---:|:---:|:---:|---|---|
|58|58 同城|-|[pic3.58cdn.com.cn](https://pic3.58cdn.com.cn/nowater/webim/big/n_v2392acc88f4a842c9a7cbe84095e21297.png)||
|alibaba|aliexpress|-|[ae01.alicdn.com](https://ae01.alicdn.com/kf/HTB1dYeZXZrrK1RjSspa763REXXaP.png)||
|baidu|百度百家号|-|[pic.rmb.bdstatic.com](https://pic.rmb.bdstatic.com/601628d09da962bb7ae33344d1529303.png)||
|jd|京东|-|[img14.360buyimg.com](https://img14.360buyimg.com/img/jfs/t27652/56/2185046614/6538/3a9cae42/5bfa42ccN6f124f96.png)||
|netease|网易严选|-|[yanxuan.nosdn.127.net](https://yanxuan.nosdn.127.net/3093b774838d230839f4b9dbf93a5e24.png)|失效|
|suning|苏宁易购|-|[image.suning.cn](https://image.suning.cn/uimg/ZR/share_order/154744665504078477.jpg)|失效|
|toutiao|今日头条|-|[p.pstatp.com](https://p.pstatp.com/origin/fed9000048fa5baac7ef)|失效|
|xiaomi|小米有品|-|[shop.io.mi-img.com](https://shop.io.mi-img.com/app/shop/img?id=shop_601628d09da962bb7ae33344d1529303.png&w=512&h=512)|失效|
|xitu|掘金|-|[user-gold-cdn.xitu.io](https://user-gold-cdn.xitu.io/2018/12/11/1679cff746d2dd30)|失效|
|bilibili|哔哩哔哩|cookie|[i0.hdslb.com](https://i0.hdslb.com/bfs/album/fc76ecf5a062a650a9cfb0c3dbda0fff021394b7.png)||
|qcloud|云+社区|cookie|[ask.qcloudimg.com](https://ask.qcloudimg.com/draft/1134330/g2oaa9bdbx.png)||
|qiniu|七牛云|cookie|[dn-odum9helk.qbox.me](https://dn-odum9helk.qbox.me/Fvx27PWgYqZQqc-ww9vaD_8CE5S3)||
|ximalaya|喜马拉雅|cookie|[fdfs.xmcdn.com](https://fdfs.xmcdn.com/group75/M05/66/40/wKgO3V5NYarzWWxAAAAZiiMZ2eE485.png)||


### Upload file

take `alibaba` for example

```javascript
upimg.alibaba
    .upload('./test/nodejs.png')
    .then(json => console.log(json))
    .catch(err => console.error(err.message))
```

success response
```json
{
  "success": true,
  "message": "success",
  "url": "https://ae01.alicdn.com/kf/HTB1dYeZXZrrK1RjSspa763REXXaP.png",
  "type": {
    "ext": "png",
    "mime": "image/png"
  }
}
```

take `qcloud` for cookies required example

```javascript
upimg.qcloud
    .set('cookie', 'foo=bar; xxx=123')
    .upload('./test/nodejs.png')
    .then(json => console.log(json))
    .catch(err => console.error(err.message))
```

success response
```json
{
  "success": true,
  "message": "success",
  "url": "https://ask.qcloudimg.com/draft/1134330/g2oaa9bdbx.png",
  "type": {
    "ext": "png",
    "mime": "image/png"
  }
}
```

## API

### upimg[server]

Returns an `class` with function:

 - `set(key, value)` - set options
 - `upload(image)` - upload image

Or `undefined` when there is no server match.

### .set(key, value)

Sets `options[key]` to `value`.

Returns a `Promise` which resolves `self`.

### .upload(image)

Upload image to CDN server.

Returns a `Promise` which resolves upload result.

 - success: `boolean`
 - message: `string`
 - url: `string(url)`
 - type: `object`
   - ext: `string`
   - mime: `string`

#### image

Type: `Buffer | string`

Pass pathname or image content buffers

## Author

**upimg** © [metowolf](https://github.com/metowolf), Released under the [MIT](./LICENSE) License.<br>

> Blog [@meto](https://i-meto.com) · GitHub [@metowolf](https://github.com/metowolf) · Twitter [@metowolf](https://twitter.com/metowolf)
